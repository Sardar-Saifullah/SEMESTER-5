import java.util.Scanner;
public class TestClass {
    public static void main(String[] args) {

        // Menu driven approach
        Scanner sc = new Scanner (System.in);
        DoublyLinkedList list = new DoublyLinkedList();
        int choice=0;
        do{
            System.out.println("<-  ----- MENU ----- -->");
            System.out.println("1) Insert Data ");
            System.out.println("2) Display Data");
            System.out.println("3) Delete Data");
            System.out.println("4) Find Data");
            System.out.println("5) Amount of Data");
            System.out.println("Any other key to Exit");
            System.out.print("Enter your choice : ");
            choice=sc.nextInt();
            switch(choice){
                case 1:

                    Patient p = insertData();

                    list.insertAtEnd(p);
                    break;
                case 2:
                    list.display();
                    break;
                case 3:
                    list.deleteById(deleteData());

                case 4:
                    list.findById(findData());
                    break;

                default:
                    choice=-1;
            }

            System.out.println("\n");
        }while(choice!=-1);

    }

    public static Patient insertData(){
        Scanner sc = new Scanner (System.in);
        System.out.print("Enter the CNIC of Patient : ");
        String CNIC =sc.nextLine();
        System.out.print("Enter the Name of Patient : ");
        String Name =sc.nextLine();
        System.out.print("Enter the age of Patient : ");
        int age =sc.nextInt();
        System.out.print("Enter the ID of Patient : ");
        int id =sc.nextInt();
        System.out.print("Enter the number of diseases patient have : ");
        int size = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the diseases : ");
        String [] dis= new String[size];
        for(int i=0;i<size;i++){
            dis[i]=sc.nextLine();
        }
        System.out.print("Enter the treatment : ");
        String treat = sc.nextLine();

        Patient p = new Patient (CNIC , Name,age,id,dis,treat);
        return p;
    }
    public static int deleteData(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the id of the person You want to delete : ");
        int id= sc.nextInt();

        return id;
    }

    public static int findData(){
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the id of the patient you want to view : ");
        int id = sc.nextInt();
        return id;
    }
}
