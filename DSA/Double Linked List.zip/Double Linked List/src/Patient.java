
public class Patient extends Person{
    private int id;
    private String[] disease;
    private String treatment;
    Patient(String CNIC,String Name,int age,int id,String[] disease,String treatment){
        super(CNIC,Name,age);
        this.id=id;
        this.disease=disease;
        this.treatment=treatment;
    }
    public void setId(int id){
        this.id = id;
    }
    public void setDisease(String [] dis){
        this.disease=dis;
    }
    public void setTreatment(String treat){
        this.treatment=treat;
    }

    public int getId(){
        return id;
    }
    public String[] getDisease(){
        return disease;
    }
    public String getTreatment(){
        return treatment;
    }
    public String toString(){
        String dis="";
        for(int i=0;i<disease.length;i++){
            dis+=disease[i];
            if(i!= disease.length-1){
                dis+=" , ";
            }
        }
        return String.format(super.toString()+"\nPatient ID : "+ id+"\nDiseases : "+dis+"\nMedicines / Treatment : "+treatment);
    }
}
