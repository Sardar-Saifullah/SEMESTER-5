class Node{
    Patient data;
    Node previous;
    Node next;

    public Node(Patient p) {
        this.data = p;
    }
}