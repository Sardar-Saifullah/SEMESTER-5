public class DoublyLinkedList{
    Node head;
    DoublyLinkedList(){
        head=null;
    }

    //Display Function
    public void display(){
        Node p = head;
        if(p!=null){
            while(p!=null){
                System.out.println(p.toString());
                p=p.next;
                System.out.println("<--------------------------------------------->");
            }
        }
        else{
            System.out.print("The List is empty");
        }
        System.out.println("");
    }
    //Count Nodes
    public int countNodes(){
        Node p = head;
        int count=0;
        while(p!=null){
            count++;
            p=p.next;
        }
        return count;
    }

    // find
    public Node find(Patient data){
        Node p = head;
        while(p!=null && !(p.data==data)){
            p=p.next;
        }
        return p;
    }
    // insert At End
    public void insertAtEnd(Patient data){
        Node n = new Node(data);
        if(head==null){
            head=n;
        }
        else{
            Node p = head;
            while (p!=null){
                p=p.next;
            }
            p.next=n;
            n.previous=p;
        }

    }

    // insert At Start
    public void insertAtStart(Patient data){
        Node n = new Node(data);
        if(head==null){
            head=n;
        }
        else{
            n.next=head;
            head.previous=n;
            head=n;
        }
    }

    // insert After( int key, int data)
    public void insertAfter(Patient key,Patient data){
        Node f= find(key);
        if(f!=null){
            Node n = new Node(data);
            n.previous=f;
            n.next=f.next;
            f.next=n;
        }
        else{
            System.out.println("The Patient with id : " + key.getId()+", Does Not exsists in the List");
        }
    }
    //Delete from End
    public void deleteFromEnd(){

        if(head==null){
            System.out.println("The list is empty");
        }
        else if(head.next==null){
            head=null;
        }
        else{
            Node p = head;
            Node q = head;
            while(p!=null){
                q=p;
                p=p.next;
            }
            p.previous=null;
            q.next=null;
        }
    }

    // Delete at specific data
    public void delete(Patient data){
        if(head==null){
            System.out.println("The list is empty");
        }
        else if(head.data==data){
            head.next.previous=null;
            head=head.next;
            head.next=null;
        }
        else{
            Node p=head;
            Node q= head;
            while(p!=head){
                q=p;
                 p=p.next;
                if(p.data==data){
                    q.next=p.next;
                    p.previous=null;
                    p.next.previous=q;
                    p.next=null;
                    return;
                }
            }
        }
        System.out.println("Node : "+ data + ", was not Found");
    }
    // Custom Functions Generated for our own
    public void deleteById(int id) {
        if (head == null) {
            System.out.println("Empty list and Node with " + id + "cannot be deleted");
        } else if (head.data.getId()==id) {

            head.next.previous=null;
            head=head.next;
            head.next=null;
        } else {
            Node p = head, q = head;
            while (p.next != null) {
                q = p;
                p = p.next;
                if (p.data.getId()==id) {
                    q.next=p.next;
                    p.previous=null;
                    p.next.previous=q;
                    p.next=null;
                    return;
                }
            }
            System.out.println("Node " + id + " was not found");
        }
    }

    public Node findById(int id) {
        Node p = head;
        while (p != null && !(p.data.getId()==id)) {
            p = p.next;
        }
        return p;
    }
}