public class CircularLinkedList{
    Node head;
    Node previous;
    CircularLinkedList(){
        head=null;
        previous=null;
    }

    //Display Function:
    // display all the records:
    public void display(){
        Node p = head;
        if(p!=null){
            do{
                System.out.println(p.data.toString());
                p=p.next;
                System.out.println("<--------------------------------------------->");
                System.out.println("so : " + (p.next!=head.next));
            }while(p.next!=head.next);
        }
        else{
            System.out.print("The List is empty");
        }
        System.out.println("");
    }
    //display specific record
    public void displayById(int id){
        if(head==null){
            System.out.println("The list is empty");
        }
        else{
            Node p = head;
            do{
                if(p.data.getId()==id){
                    System.out.println(p.data.toString());
                    break;
                }
                p=p.next;
            }while(p.next!=head.next);
        }
    }
    //Count Nodes
    public int countNodes(){
        Node p = head;
        int count=0;
        if(p!=null) {
            do {
                count++;
                p = p.next;
            } while (p.next != head.next);
        }
        return count;
    }

    // find
    public Node find(Patient data){
        Node p = head;
        if(p!=null) {
            do {
                p=p.next;
            } while (p.next != head.next && !(p.data==data));
        }
        return p.previous;
    }
    // insert At End
    public void insertAtEnd(Patient data){
        Node n = new Node(data);
        if(head==null){
            head=n;
            head.next=n;
            head.previous=n;
        }
        else{
            n.next=head;
            n.previous=head.previous;
            head.previous.next=n;
            head.previous=n;
        }
    }

    // insert At Start
    public void insertAtStart(Patient data){
        Node n = new Node(data);
        if(head==null){
            head=n;
            head.next=n;
            head.previous=n;
        }
        else{
            n.next=head;
            n.previous=head.previous;
            head.previous.next=n;
            head.previous=n;
            head=n;
        }
    }

    // insert After( int key, int data)
    public void insertAfter(Patient key,Patient data){
        Node f= find(key);
        if(f!=null){
            Node n = new Node(data);
            n.next=f.next;
            n.previous=f;
            f.next.previous=n;
            f.next=n;//Till here
        }
        else{
            System.out.println("The Patient with id : " + key.getId()+", Does Not exsists in the List");
        }
    }

    //Delete from End
    public void deleteFromEnd(){

        if(head==null){
            System.out.println("The list is empty");
        }
        else{
            Node p = head;
            Node q = head;
            do{
                q=p;
                p=p.next;
            }while(p.next!=head.next);
            q.previous.next=p;
            p.previous=q.previous;
            q.next=null;
            q.previous=null;
        }
    }

    // Delete at specific data
    public void delete(Patient data){
        if(head==null){
            System.out.println("The list is empty");
        }
        else {
            Node f = find(data);
            f.previous.next=f.next;
            f.next.previous=f.previous;
            f.next=null;
            f.previous=null;
            return;
        }
        System.out.println("Patient of id : "+ data.getId() + ", is not Found");
    }
}