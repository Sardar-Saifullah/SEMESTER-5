
public class Person {
    private String CNIC;
    private String Name;
    private int age;

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    Person(String CNIC, String Name, int age){
        this.CNIC =CNIC;
        this.Name=Name;
        this.age=age;
    }
    Person(){
        CNIC=null;
        Name=null;
        age=0;
    }
    public String toString(){
        return String.format("CNIC : "+ CNIC+"\nName : "+ Name+"\nAGE : "+ age);
    }

}
