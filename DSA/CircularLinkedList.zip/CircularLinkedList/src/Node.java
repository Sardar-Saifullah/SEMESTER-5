public class Node {
    Patient data;
    Node next;
    Node previous;
    Node(Patient p){
        data=p;
        next=null;
        previous=null;
    }
}
